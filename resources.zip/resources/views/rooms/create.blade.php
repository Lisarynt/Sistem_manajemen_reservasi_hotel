<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl ...">Tambah Kamar</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <form action="{{ route('rooms.store') }}" method="POST" enctype="multipart/form-data" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block dark:text-gray-200">Tipe Kamar</label>
                        <select name="room_type_id" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            @foreach ($roomTypes as $type)
                                <option value="{{ $type->id }}">{{ $type->name }}</option>
                            @endforeach
                        </select>
                        @error('room_type_id') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Nomor Kamar</label>
                        <input type="text" name="room_number" value="{{ old('room_number') }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('room_number') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Status</label>
                        <select name="status" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            <option value="available">Available</option>
                            <option value="occupied">Occupied</option>
                            <option value="maintenance">Maintenance</option>
                        </select>
                        @error('status') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Foto Kamar (bisa pilih beberapa)</label>
                        <input type="file" name="images[]" multiple accept="image/*" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('images.*') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Simpan</button>
                        <a href="{{ route('rooms.index') }}" class="bg-gray-300 px-4 py-2 rounded">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>