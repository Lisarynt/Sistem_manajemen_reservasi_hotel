<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl ...">Edit Kamar</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">

                @if ($room->images->count())
                    <div class="mb-4">
                        <label class="block dark:text-gray-200 mb-2">Foto Saat Ini</label>
                        <div class="flex flex-wrap gap-3">
                            @foreach ($room->images as $image)
                                <div class="relative">
                                    <img src="{{ Storage::url($image->image_path) }}" class="w-24 h-24 object-cover rounded">
                                    <form action="{{ route('room-images.destroy', $image) }}" method="POST" class="absolute top-0 right-0" onsubmit="return confirm('Hapus gambar ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="bg-red-600 text-white text-xs px-1 rounded">X</button>
                                    </form>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif

                <form action="{{ route('rooms.update', $room) }}" method="POST" enctype="multipart/form-data" class="space-y-4">
                    @csrf
                    @method('PUT')

                    <div>
                        <label class="block dark:text-gray-200">Tipe Kamar</label>
                        <select name="room_type_id" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            @foreach ($roomTypes as $type)
                                <option value="{{ $type->id }}" {{ $room->room_type_id == $type->id ? 'selected' : '' }}>{{ $type->name }}</option>
                            @endforeach
                        </select>
                        @error('room_type_id') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Nomor Kamar</label>
                        <input type="text" name="room_number" value="{{ old('room_number', $room->room_number) }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('room_number') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Status</label>
                        <select name="status" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            <option value="available" {{ $room->status == 'available' ? 'selected' : '' }}>Available</option>
                            <option value="occupied" {{ $room->status == 'occupied' ? 'selected' : '' }}>Occupied</option>
                            <option value="maintenance" {{ $room->status == 'maintenance' ? 'selected' : '' }}>Maintenance</option>
                        </select>
                        @error('status') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Tambah Foto Baru (opsional)</label>
                        <input type="file" name="images[]" multiple accept="image/*" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('images.*') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Update</button>
                        <a href="{{ route('rooms.index') }}" class="bg-gray-300 px-4 py-2 rounded">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>