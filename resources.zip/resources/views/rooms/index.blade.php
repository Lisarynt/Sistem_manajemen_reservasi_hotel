<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl ...">Data Kamar</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">

                @if (session('success'))
                    <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">
                        {{ session('success') }}
                    </div>
                @endif

                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold dark:text-white">Daftar Kamar</h3>
                    @if (auth()->user()->role === 'admin')
                        <a href="{{ route('rooms.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                            + Tambah Kamar
                        </a>
                    @endif
                </div>

                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b dark:border-gray-600">
                            <th class="py-2 dark:text-gray-200">Foto</th>
                            <th class="py-2 dark:text-gray-200">No. Kamar</th>
                            <th class="py-2 dark:text-gray-200">Tipe</th>
                            <th class="py-2 dark:text-gray-200">Status</th>
                            <th class="py-2 dark:text-gray-200">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($rooms as $room)
                            <tr class="border-b dark:border-gray-700">
                                <td class="py-2">
                                    @if ($room->images->first())
                                        <img src="{{ Storage::url($room->images->first()->image_path) }}" class="w-16 h-16 object-cover rounded">
                                    @else
                                        <span class="text-gray-400 text-sm">Tidak ada</span>
                                    @endif
                                </td>
                                <td class="py-2 dark:text-gray-300">{{ $room->room_number }}</td>
                                <td class="py-2 dark:text-gray-300">{{ $room->roomType->name }}</td>
                                <td class="py-2 dark:text-gray-300">
                                    <span class="px-2 py-1 rounded text-xs
                                        @if($room->status === 'available') bg-green-100 text-green-800
                                        @elseif($room->status === 'occupied') bg-red-100 text-red-800
                                        @else bg-yellow-100 text-yellow-800 @endif">
                                        {{ ucfirst($room->status) }}
                                    </span>
                                </td>
                                <td class="py-2 space-x-2">
                                    <a href="{{ route('rooms.show', $room) }}" class="text-blue-600 hover:underline">Detail</a>
                                    @if (auth()->user()->role === 'admin')
                                        <a href="{{ route('rooms.edit', $room) }}" class="text-yellow-600 hover:underline">Edit</a>
                                        <form action="{{ route('rooms.destroy', $room) }}" method="POST" class="inline" onsubmit="return confirm('Yakin hapus kamar ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="py-4 text-center text-gray-500">Belum ada data.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="mt-4">
                    {{ $rooms->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>