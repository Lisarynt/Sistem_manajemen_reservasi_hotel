<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl ...">Detail Kamar</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-3">
                @if ($room->images->count())
                    <div class="flex flex-wrap gap-3 mb-4">
                        @foreach ($room->images as $image)
                            <img src="{{ Storage::url($image->image_path) }}" class="w-32 h-32 object-cover rounded">
                        @endforeach
                    </div>
                @endif

                <p class="dark:text-gray-200"><strong>Nomor Kamar:</strong> {{ $room->room_number }}</p>
                <p class="dark:text-gray-200"><strong>Tipe:</strong> {{ $room->roomType->name }}</p>
                <p class="dark:text-gray-200"><strong>Status:</strong> {{ ucfirst($room->status) }}</p>

                <a href="{{ route('rooms.index') }}" class="inline-block bg-gray-300 px-4 py-2 rounded mt-4">Kembali</a>
            </div>
        </div>
    </div>
</x-app-layout>