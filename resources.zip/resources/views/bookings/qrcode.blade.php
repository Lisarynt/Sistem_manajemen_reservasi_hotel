<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            QR Code Booking
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-lg mx-auto sm:px-6 lg:px-8 text-center">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <p class="mb-4 dark:text-gray-200">Kode Booking: <strong>{{ $booking->booking_code }}</strong></p>
                <div class="flex justify-center bg-white p-4 rounded inline-block">
                    {!! $qrcode !!}
                </div>
                <p class="mt-4 text-sm text-gray-500">Tunjukkan QR Code ini saat check-in di resepsionis.</p>

                <a href="{{ route('bookings.show', $booking) }}" class="inline-block mt-4 bg-gray-300 px-4 py-2 rounded">Kembali</a>
            </div>
        </div>
    </div>
</x-app-layout>