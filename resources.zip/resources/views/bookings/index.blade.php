<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Booking
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">

                @if (session('success'))
                    <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">{{ session('success') }}</div>
                @endif
                @if (session('error'))
                    <div class="mb-4 p-4 bg-red-100 text-red-800 rounded">{{ session('error') }}</div>
                @endif

                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold dark:text-white">Daftar Booking</h3>
                    <a href="{{ route('bookings.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                        + Buat Booking
                    </a>
                </div>

                <form method="GET" action="{{ route('bookings.index') }}" class="mb-4">
                    <input type="text" name="search" value="{{ $search }}" placeholder="Cari kode booking atau nama tamu..."
                        class="w-full md:w-1/3 rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                </form>

                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b dark:border-gray-600">
                            <th class="py-2 dark:text-gray-200">Kode</th>
                            <th class="py-2 dark:text-gray-200">Tamu</th>
                            <th class="py-2 dark:text-gray-200">Kamar</th>
                            <th class="py-2 dark:text-gray-200">Check-In</th>
                            <th class="py-2 dark:text-gray-200">Check-Out</th>
                            <th class="py-2 dark:text-gray-200">Status</th>
                            <th class="py-2 dark:text-gray-200">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($bookings as $booking)
                            <tr class="border-b dark:border-gray-700">
                                <td class="py-2 dark:text-gray-300">{{ $booking->booking_code }}</td>
                                <td class="py-2 dark:text-gray-300">{{ $booking->guest->name }}</td>
                                <td class="py-2 dark:text-gray-300">{{ $booking->room->room_number }}</td>
                                <td class="py-2 dark:text-gray-300">{{ $booking->checkin_date->format('d/m/Y') }}</td>
                                <td class="py-2 dark:text-gray-300">{{ $booking->checkout_date->format('d/m/Y') }}</td>
                                <td class="py-2">
                                    <span class="px-2 py-1 rounded text-xs
                                        @if($booking->status === 'checked_in') bg-green-100 text-green-800
                                        @elseif($booking->status === 'checked_out') bg-gray-200 text-gray-800
                                        @elseif($booking->status === 'cancelled') bg-red-100 text-red-800
                                        @else bg-yellow-100 text-yellow-800 @endif">
                                        {{ str_replace('_', ' ', ucfirst($booking->status)) }}
                                    </span>
                                </td>
                                <td class="py-2 space-x-1">
                                    <a href="{{ route('bookings.show', $booking) }}" class="text-blue-600 hover:underline">Detail</a>
                                    <a href="{{ route('bookings.edit', $booking) }}" class="text-yellow-600 hover:underline">Edit</a>

                                    @if (in_array($booking->status, ['pending', 'confirmed']))
                                        <form action="{{ route('bookings.checkin', $booking) }}" method="POST" class="inline">
                                            @csrf
                                            <button type="submit" class="text-green-600 hover:underline">Check-In</button>
                                        </form>
                                    @endif

                                    @if ($booking->status === 'checked_in')
                                        <form action="{{ route('bookings.checkout', $booking) }}" method="POST" class="inline">
                                            @csrf
                                            <button type="submit" class="text-purple-600 hover:underline">Check-Out</button>
                                        </form>
                                    @endif

                                    <a href="{{ route('bookings.qrcode', $booking) }}" class="text-indigo-600 hover:underline" target="_blank">QR</a>

                                    <form action="{{ route('bookings.destroy', $booking) }}" method="POST" class="inline" onsubmit="return confirm('Yakin hapus booking ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="py-4 text-center text-gray-500">Belum ada data.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="mt-4">
                    {{ $bookings->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>