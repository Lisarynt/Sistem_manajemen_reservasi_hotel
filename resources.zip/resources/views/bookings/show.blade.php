<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Detail Booking
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-3">
                <p class="dark:text-gray-200"><strong>Kode Booking:</strong> {{ $booking->booking_code }}</p>
                <p class="dark:text-gray-200"><strong>Tamu:</strong> {{ $booking->guest->name }}</p>
                <p class="dark:text-gray-200"><strong>Kamar:</strong> {{ $booking->room->room_number }} ({{ $booking->room->roomType->name }})</p>
                <p class="dark:text-gray-200"><strong>Check-In:</strong> {{ $booking->checkin_date->format('d/m/Y') }}</p>
                <p class="dark:text-gray-200"><strong>Check-Out:</strong> {{ $booking->checkout_date->format('d/m/Y') }}</p>
                <p class="dark:text-gray-200"><strong>Status:</strong> {{ str_replace('_', ' ', ucfirst($booking->status)) }}</p>

                @if ($booking->actual_checkin_at)
                    <p class="dark:text-gray-200"><strong>Waktu Check-In Aktual:</strong> {{ $booking->actual_checkin_at->format('d/m/Y H:i') }}</p>
                @endif
                @if ($booking->actual_checkout_at)
                    <p class="dark:text-gray-200"><strong>Waktu Check-Out Aktual:</strong> {{ $booking->actual_checkout_at->format('d/m/Y H:i') }}</p>
                @endif

                <div class="mt-4">
                    <h4 class="font-semibold dark:text-white mb-2">Fasilitas Tambahan</h4>
                    @forelse ($booking->facilities as $facility)
                        <p class="dark:text-gray-300">- {{ $facility->name }} (Rp {{ number_format($facility->price, 0, ',', '.') }})</p>
                    @empty
                        <p class="text-gray-500">Tidak ada fasilitas tambahan.</p>
                    @endforelse
                </div>

                <div class="flex space-x-2 mt-6">
                    <a href="{{ route('bookings.qrcode', $booking) }}" target="_blank" class="bg-indigo-600 text-white px-4 py-2 rounded">Lihat QR Code</a>
                    <a href="{{ route('bookings.index') }}" class="bg-gray-300 px-4 py-2 rounded">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>