<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Buat Booking
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <form action="{{ route('bookings.store') }}" method="POST" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block dark:text-gray-200">Tamu</label>
                        <select name="guest_id" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            <option value="">-- Pilih Tamu --</option>
                            @foreach ($guests as $guest)
                                <option value="{{ $guest->id }}">{{ $guest->name }} ({{ $guest->phone }})</option>
                            @endforeach
                        </select>
                        @error('guest_id') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Kamar (hanya yang tersedia)</label>
                        <select name="room_id" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            <option value="">-- Pilih Kamar --</option>
                            @foreach ($rooms as $room)
                                <option value="{{ $room->id }}">{{ $room->room_number }} - {{ $room->roomType->name }}</option>
                            @endforeach
                        </select>
                        @error('room_id') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block dark:text-gray-200">Tanggal Check-In</label>
                            <input type="date" name="checkin_date" value="{{ old('checkin_date') }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            @error('checkin_date') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="block dark:text-gray-200">Tanggal Check-Out</label>
                            <input type="date" name="checkout_date" value="{{ old('checkout_date') }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            @error('checkout_date') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                        </div>
                    </div>

                    <div>
                        <label class="block dark:text-gray-200 mb-2">Fasilitas Tambahan (opsional)</label>
                        @foreach ($facilities as $facility)
                            <label class="flex items-center space-x-2 dark:text-gray-300">
                                <input type="checkbox" name="facilities[]" value="{{ $facility->id }}">
                                <span>{{ $facility->name }} (Rp {{ number_format($facility->price, 0, ',', '.') }})</span>
                            </label>
                        @endforeach
                    </div>

                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Simpan</button>
                        <a href="{{ route('bookings.index') }}" class="bg-gray-300 px-4 py-2 rounded">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>