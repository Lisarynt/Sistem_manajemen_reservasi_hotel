<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Edit Booking
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <form action="{{ route('bookings.update', $booking) }}" method="POST" class="space-y-4">
                    @csrf
                    @method('PUT')

                    <div>
                        <label class="block dark:text-gray-200">Tamu</label>
                        <select name="guest_id" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            @foreach ($guests as $guest)
                                <option value="{{ $guest->id }}" {{ $booking->guest_id == $guest->id ? 'selected' : '' }}>{{ $guest->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Kamar</label>
                        <select name="room_id" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            @foreach ($rooms as $room)
                                <option value="{{ $room->id }}" {{ $booking->room_id == $room->id ? 'selected' : '' }}>{{ $room->room_number }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block dark:text-gray-200">Tanggal Check-In</label>
                            <input type="date" name="checkin_date" value="{{ $booking->checkin_date->format('Y-m-d') }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        </div>
                        <div>
                            <label class="block dark:text-gray-200">Tanggal Check-Out</label>
                            <input type="date" name="checkout_date" value="{{ $booking->checkout_date->format('Y-m-d') }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        </div>
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Status</label>
                        <select name="status" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                            <option value="pending" {{ $booking->status == 'pending' ? 'selected' : '' }}>Pending</option>
                            <option value="confirmed" {{ $booking->status == 'confirmed' ? 'selected' : '' }}>Confirmed</option>
                            <option value="checked_in" {{ $booking->status == 'checked_in' ? 'selected' : '' }}>Checked In</option>
                            <option value="checked_out" {{ $booking->status == 'checked_out' ? 'selected' : '' }}>Checked Out</option>
                            <option value="cancelled" {{ $booking->status == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                        </select>
                    </div>

                    <div>
                        <label class="block dark:text-gray-200 mb-2">Fasilitas Tambahan</label>
                        @foreach ($facilities as $facility)
                            <label class="flex items-center space-x-2 dark:text-gray-300">
                                <input type="checkbox" name="facilities[]" value="{{ $facility->id }}"
                                    {{ $booking->facilities->contains($facility->id) ? 'checked' : '' }}>
                                <span>{{ $facility->name }}</span>
                            </label>
                        @endforeach
                    </div>

                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Update</button>
                        <a href="{{ route('bookings.index') }}" class="bg-gray-300 px-4 py-2 rounded">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>