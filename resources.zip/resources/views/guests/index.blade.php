<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Data Tamu
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">

                @if (session('success'))
                    <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">{{ session('success') }}</div>
                @endif
                @if (session('error'))
                    <div class="mb-4 p-4 bg-red-100 text-red-800 rounded">{{ session('error') }}</div>
                @endif

                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold dark:text-white">Daftar Tamu</h3>
                    <a href="{{ route('guests.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                        + Tambah Tamu
                    </a>
                </div>

                <form method="GET" action="{{ route('guests.index') }}" class="mb-4">
                    <input type="text" name="search" value="{{ $search }}" placeholder="Cari nama, telepon, atau no. identitas..."
                        class="w-full md:w-1/3 rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                </form>

                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b dark:border-gray-600">
                            <th class="py-2 dark:text-gray-200">Nama</th>
                            <th class="py-2 dark:text-gray-200">Telepon</th>
                            <th class="py-2 dark:text-gray-200">No. Identitas</th>
                            <th class="py-2 dark:text-gray-200">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($guests as $guest)
                            <tr class="border-b dark:border-gray-700">
                                <td class="py-2 dark:text-gray-300">{{ $guest->name }}</td>
                                <td class="py-2 dark:text-gray-300">{{ $guest->phone }}</td>
                                <td class="py-2 dark:text-gray-300">{{ $guest->id_number }}</td>
                                <td class="py-2 space-x-2">
                                    <a href="{{ route('guests.show', $guest) }}" class="text-blue-600 hover:underline">Detail</a>
                                    <a href="{{ route('guests.edit', $guest) }}" class="text-yellow-600 hover:underline">Edit</a>
                                    <form action="{{ route('guests.destroy', $guest) }}" method="POST" class="inline" onsubmit="return confirm('Yakin hapus tamu ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="py-4 text-center text-gray-500">Belum ada data.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="mt-4">
                    {{ $guests->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>