<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Detail Tamu
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-3">
                <p class="dark:text-gray-200"><strong>Nama:</strong> {{ $guest->name }}</p>
                <p class="dark:text-gray-200"><strong>Email:</strong> {{ $guest->email ?? '-' }}</p>
                <p class="dark:text-gray-200"><strong>Telepon:</strong> {{ $guest->phone }}</p>
                <p class="dark:text-gray-200"><strong>No. KTP/Paspor:</strong> {{ $guest->id_number }}</p>
                <p class="dark:text-gray-200"><strong>Alamat:</strong> {{ $guest->address ?? '-' }}</p>

                <div class="mt-6">
                    <h4 class="font-semibold dark:text-white mb-2">Riwayat Booking</h4>
                    @forelse ($guest->bookings as $booking)
                        <div class="border-b dark:border-gray-700 py-2 dark:text-gray-300">
                            {{ $booking->booking_code }} — Kamar {{ $booking->room->room_number }} —
                            <span class="capitalize">{{ str_replace('_', ' ', $booking->status) }}</span>
                        </div>
                    @empty
                        <p class="text-gray-500">Belum ada riwayat booking.</p>
                    @endforelse
                </div>

                <a href="{{ route('guests.index') }}" class="inline-block bg-gray-300 px-4 py-2 rounded mt-4">Kembali</a>
            </div>
        </div>
    </div>
</x-app-layout>