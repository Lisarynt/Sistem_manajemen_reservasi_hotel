<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Edit Tamu
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <form action="{{ route('guests.update', $guest) }}" method="POST" class="space-y-4">
                    @csrf
                    @method('PUT')

                    <div>
                        <label class="block dark:text-gray-200">Nama Lengkap</label>
                        <input type="text" name="name" value="{{ old('name', $guest->name) }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('name') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Email (opsional)</label>
                        <input type="email" name="email" value="{{ old('email', $guest->email) }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('email') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">No. Telepon</label>
                        <input type="text" name="phone" value="{{ old('phone', $guest->phone) }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('phone') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">No. KTP/Paspor</label>
                        <input type="text" name="id_number" value="{{ old('id_number', $guest->id_number) }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('id_number') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Alamat (opsional)</label>
                        <textarea name="address" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">{{ old('address', $guest->address) }}</textarea>
                        @error('address') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Update</button>
                        <a href="{{ route('guests.index') }}" class="bg-gray-300 px-4 py-2 rounded">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>