<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Fasilitas
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">

                @if (session('success'))
                    <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">
                        {{ session('success') }}
                    </div>
                @endif

                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold dark:text-white">Daftar Fasilitas</h3>
                    @if (auth()->user()->role === 'admin')
                        <a href="{{ route('facilities.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                            + Tambah Fasilitas
                        </a>
                    @endif
                </div>

                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b dark:border-gray-600">
                            <th class="py-2 dark:text-gray-200">Nama</th>
                            <th class="py-2 dark:text-gray-200">Harga</th>
                            <th class="py-2 dark:text-gray-200">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($facilities as $facility)
                            <tr class="border-b dark:border-gray-700">
                                <td class="py-2 dark:text-gray-300">{{ $facility->name }}</td>
                                <td class="py-2 dark:text-gray-300">Rp {{ number_format($facility->price, 0, ',', '.') }}</td>
                                <td class="py-2 space-x-2">
                                    <a href="{{ route('facilities.show', $facility) }}" class="text-blue-600 hover:underline">Detail</a>
                                    @if (auth()->user()->role === 'admin')
                                        <a href="{{ route('facilities.edit', $facility) }}" class="text-yellow-600 hover:underline">Edit</a>
                                        <form action="{{ route('facilities.destroy', $facility) }}" method="POST" class="inline" onsubmit="return confirm('Yakin hapus fasilitas ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="3" class="py-4 text-center text-gray-500">Belum ada data.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="mt-4">
                    {{ $facilities->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>