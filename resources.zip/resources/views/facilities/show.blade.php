<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Detail Fasilitas
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-3">
                <p class="dark:text-gray-200"><strong>Nama:</strong> {{ $facility->name }}</p>
                <p class="dark:text-gray-200"><strong>Harga:</strong> Rp {{ number_format($facility->price, 0, ',', '.') }}</p>

                <a href="{{ route('facilities.index') }}" class="inline-block bg-gray-300 px-4 py-2 rounded mt-4">Kembali</a>
            </div>
        </div>
    </div>
</x-app-layout>