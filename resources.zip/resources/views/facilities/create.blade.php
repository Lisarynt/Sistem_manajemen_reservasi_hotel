<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Tambah Fasilitas
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <form action="{{ route('facilities.store') }}" method="POST" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block dark:text-gray-200">Nama Fasilitas</label>
                        <input type="text" name="name" value="{{ old('name') }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('name') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Harga</label>
                        <input type="number" name="price" value="{{ old('price') }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('price') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Simpan</button>
                        <a href="{{ route('facilities.index') }}" class="bg-gray-300 px-4 py-2 rounded">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>