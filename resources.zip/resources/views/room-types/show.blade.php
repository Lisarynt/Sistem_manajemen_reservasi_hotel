<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl ...">Detail Tipe Kamar</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-3">
                <p class="dark:text-gray-200"><strong>Nama:</strong> {{ $roomType->name }}</p>
                <p class="dark:text-gray-200"><strong>Deskripsi:</strong> {{ $roomType->description ?? '-' }}</p>
                <p class="dark:text-gray-200"><strong>Harga per Malam:</strong> Rp {{ number_format($roomType->price_per_night, 0, ',', '.') }}</p>

                <a href="{{ route('room-types.index') }}" class="inline-block bg-gray-300 px-4 py-2 rounded mt-4">Kembali</a>
            </div>
        </div>
    </div>
</x-app-layout>