<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl ...">Tipe Kamar</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">

                @if (session('success'))
                    <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">
                        {{ session('success') }}
                    </div>
                @endif

                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold dark:text-white">Daftar Tipe Kamar</h3>
                    @if (auth()->user()->role === 'admin')
                        <a href="{{ route('room-types.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                            + Tambah Tipe Kamar
                        </a>
                    @endif
                </div>

                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b dark:border-gray-600">
                            <th class="py-2 dark:text-gray-200">Nama</th>
                            <th class="py-2 dark:text-gray-200">Deskripsi</th>
                            <th class="py-2 dark:text-gray-200">Harga/Malam</th>
                            <th class="py-2 dark:text-gray-200">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($roomTypes as $roomType)
                            <tr class="border-b dark:border-gray-700">
                                <td class="py-2 dark:text-gray-300">{{ $roomType->name }}</td>
                                <td class="py-2 dark:text-gray-300">{{ Str::limit($roomType->description, 40) }}</td>
                                <td class="py-2 dark:text-gray-300">Rp {{ number_format($roomType->price_per_night, 0, ',', '.') }}</td>
                                <td class="py-2 space-x-2">
                                    <a href="{{ route('room-types.show', $roomType) }}" class="text-blue-600 hover:underline">Detail</a>
                                    @if (auth()->user()->role === 'admin')
                                        <a href="{{ route('room-types.edit', $roomType) }}" class="text-yellow-600 hover:underline">Edit</a>
                                        <form action="{{ route('room-types.destroy', $roomType) }}" method="POST" class="inline" onsubmit="return confirm('Yakin hapus tipe kamar ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="py-4 text-center text-gray-500">Belum ada data.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="mt-4">
                    {{ $roomTypes->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>