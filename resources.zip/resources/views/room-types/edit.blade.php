<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl ...">Edit Tipe Kamar</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
                <form action="{{ route('room-types.update', $roomType) }}" method="POST" class="space-y-4">
                    @csrf
                    @method('PUT')

                    <div>
                        <label class="block dark:text-gray-200">Nama Tipe Kamar</label>
                        <input type="text" name="name" value="{{ old('name', $roomType->name) }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('name') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Deskripsi</label>
                        <textarea name="description" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">{{ old('description', $roomType->description) }}</textarea>
                        @error('description') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block dark:text-gray-200">Harga per Malam</label>
                        <input type="number" name="price_per_night" value="{{ old('price_per_night', $roomType->price_per_night) }}" class="w-full rounded border-gray-300 dark:bg-gray-700 dark:text-white">
                        @error('price_per_night') <p class="text-red-500 text-sm">{{ $message }}</p> @enderror
                    </div>

                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Update</button>
                        <a href="{{ route('room-types.index') }}" class="bg-gray-300 px-4 py-2 rounded">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>